const bacem = artifacts.require("bacem");

module.exports = function(_deployer) {

  _deployer.deploy(bacem);
};
