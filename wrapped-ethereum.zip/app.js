const contractAddress = "0x0e7BDA2DB49F00E8B3059E3d471dF7CEa822Da11"; // Replace with your deployed contract address

const provider = new ethers.providers.Web3Provider(window.ethereum);
let signer;
let contract;

const connectButton = document.getElementById('connectButton');
const walletInfo = document.getElementById('walletInfo');
const accountSpan = document.getElementById('account');
const balanceSpan = document.getElementById('balance');
const actionsDiv = document.getElementById('actions');

const depositButton = document.getElementById('depositButton');
const withdrawButton = document.getElementById('withdrawButton');
const transferButton = document.getElementById('transferButton');

connectButton.addEventListener('click', async () => {
    await provider.send("eth_requestAccounts", []);
    signer = provider.getSigner();
    contract = new ethers.Contract(contractAddress, contractABI, signer);
    const address = await signer.getAddress();
    accountSpan.innerText = address;
    walletInfo.style.display = 'block';
    actionsDiv.style.display = 'block';
    connectButton.style.display = 'none';
    updateBalance();
});

async function updateBalance() {
    const balance = await contract.balanceOf(await signer.getAddress());
    balanceSpan.innerText = ethers.utils.formatEther(balance);
}

depositButton.addEventListener('click', async () => {
    const amount = document.getElementById('depositAmount').value;
    const tx = await contract.deposit({ value: ethers.utils.parseEther(amount) });
    await tx.wait();
    updateBalance();
});

withdrawButton.addEventListener('click', async () => {
    const amount = document.getElementById('withdrawAmount').value;
    const tx = await contract.withdraw(ethers.utils.parseEther(amount));
    await tx.wait();
    updateBalance();
});

transferButton.addEventListener('click', async () => {
    const address = document.getElementById('transferAddress').value;
    const amount = document.getElementById('transferAmount').value;
    const tx = await contract.transfer(address, ethers.utils.parseEther(amount));
    await tx.wait();
    updateBalance();
});