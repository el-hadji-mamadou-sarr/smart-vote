const bacem = artifacts.require("bacem");

/*
 * uncomment accounts to access the test accounts made available by the
 * Ethereum client
 * See docs: https://www.trufflesuite.com/docs/truffle/testing/writing-tests-in-javascript
 */
contract("bacem", function (/* accounts */) {
  
  it("should assert true", async function () {
    await bacem.deployed();
    return assert.isTrue(true);
  });

  it("should return 'Hello, World Bacem!'", async function () {
    const instance = await bacem.deployed();
    const result = await instance.hello();
    assert.equal(result, "Hello, World Bacem!", "The hello function did not return the expected string.");
  });
});
